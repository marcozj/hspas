#!/bin/bash
set -x
PGLIBDIR=$(pg_config --libdir)
PKGLIBDIR=$(pg_config --pkglibdir)
EXTLIB=$(grep module_pathname plv8.control | cut -f2 -d"'" | sed -e "s,\$libdir,$PKGLIBDIR,")
EXTDIR=$(pg_config --sharedir)/extension

/bin/mkdir -p "$PKGLIBDIR"
/bin/mkdir -p "$EXTDIR"
/usr/bin/install -c -m 755  plv8-2.3.15.so "${PKGLIBDIR}/plv8-2.3.15.so"
/usr/bin/install -c -m 644 .//plv8.control "$EXTDIR"
/usr/bin/install -c -m 644 .//plv8.control .//plv8--2.3.15.sql .//upgrade/plv8--1.5.6--2.3.15.sql .//upgrade/plv8--2.3.3--2.3.15.sql .//upgrade/plv8--2.3.7--2.3.15.sql .//upgrade/plv8--2.0.0--2.3.15.sql .//upgrade/plv8--2.3.0--2.3.15.sql .//upgrade/plv8--1.5.3--2.3.15.sql .//upgrade/plv8--2.3.14--2.3.15.sql .//upgrade/plv8--2.3.13--2.3.15.sql .//upgrade/plv8--2.3.4--2.3.15.sql .//upgrade/plv8--2.3.1--2.3.15.sql .//upgrade/plv8--1.5.4--2.3.15.sql .//upgrade/plv8--1.5.1--2.3.15.sql .//upgrade/plv8--2.3.6--2.3.15.sql .//upgrade/plv8--2.3.5--2.3.15.sql .//upgrade/plv8--2.3.11--2.3.15.sql .//upgrade/plv8--2.3.2--2.3.15.sql .//upgrade/plv8--1.5.5--2.3.15.sql .//upgrade/plv8--2.0.3--2.3.15.sql .//upgrade/plv8--1.5.2--2.3.15.sql .//upgrade/plv8--2.0.1--2.3.15.sql .//upgrade/plv8--2.3.12--2.3.15.sql .//upgrade/plv8--2.1.0--2.3.15.sql .//upgrade/plv8--1.5.7--2.3.15.sql .//upgrade/plv8--2.1.2--2.3.15.sql .//upgrade/plv8--2.3.10--2.3.15.sql .//upgrade/plv8--2.3.9--2.3.15.sql .//upgrade/plv8--1.5.0--2.3.15.sql .//upgrade/plv8--2.3.8--2.3.15.sql .//plcoffee.control .//plcoffee--2.3.15.sql .//plls.control .//plls--2.3.15.sql "$EXTDIR"
/bin/mkdir -p "${PKGLIBDIR}/bitcode/plv8-2.3.15"
/usr/bin/install -c -m 644 plv8.bc "${PKGLIBDIR}/bitcode/plv8-2.3.15/"
/usr/bin/install -c -m 644 plv8_type.bc "${PKGLIBDIR}/bitcode/plv8-2.3.15/"
/usr/bin/install -c -m 644 plv8_func.bc "${PKGLIBDIR}/bitcode/plv8-2.3.15/"
/usr/bin/install -c -m 644 plv8_param.bc "${PKGLIBDIR}/bitcode/plv8-2.3.15/"
/usr/bin/install -c -m 644 coffee-script.bc "${PKGLIBDIR}/bitcode/plv8-2.3.15/"
/usr/bin/install -c -m 644 livescript.bc "${PKGLIBDIR}/bitcode/plv8-2.3.15/"
cd "${PKGLIBDIR}/bitcode" && /usr/bin/llvm-lto -thinlto -thinlto-action=thinlink -o plv8-2.3.15.index.bc plv8-2.3.15/plv8.bc plv8-2.3.15/plv8_type.bc plv8-2.3.15/plv8_func.bc plv8-2.3.15/plv8_param.bc plv8-2.3.15/coffee-script.bc plv8-2.3.15/livescript.bc
